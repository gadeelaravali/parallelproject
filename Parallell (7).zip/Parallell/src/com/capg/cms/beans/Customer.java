package com.capg.cms.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="Bank_Management")
public class Customer  implements Serializable {
	@Id

 private int accno = (int)(Math.random()*9000000)+10000000;
	private String cname;
	private String addr;
	//private String addr;
	private int amt;
	private String mobileno;
	private int age;
	private String panno;
	// StringBuffer sb=new StringBuffer();
	 @OneToMany(mappedBy="customer",cascade=CascadeType.ALL, fetch=FetchType.LAZY)
		private List<Transaction> transactions = new ArrayList<Transaction>();
	/*public StringBuffer getSb() {
		return sb;
	}
	public void setSb(StringBuffer sb) {
		this.sb = sb;
	}*/
	private int pin=(int)(Math.random()*900)+100;
			public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
			public Customer(String cname,String addr, int amt,
			String mobileno, int age, String panno) {
		// TODO Auto-generated constructor stub
		this.cname=cname;
		this.addr=addr;
		this.amt=amt;
		this.mobileno=mobileno;
		this.age=age;
		this.panno=panno;		
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPanno() {
		return panno;
	}
	public void setPanno(String panno) {
		this.panno = panno;
	}
	public int getAmt() {
		return amt;
	}
	public void setAmt(int amt) {
		this.amt = amt;
	}
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	@Override
	public String toString() {
		return "Customer [accno=" + accno + ", cname=" + cname + ", addr="
				+ addr + ", amt=" + amt + ", mobileno=" + mobileno + ", age="
				+ age + ", panno=" + panno + ", pin=" + pin + "]";
	}
	
	public Customer() {
		super();
	
	}
	public void addTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		transaction.setCustomer(this);	
		this.getTransactions().add(transaction);
	}
	public List<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}
	
}
