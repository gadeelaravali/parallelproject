package com.capg.cms.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.cms.beans.Customer;
import com.capg.cms.exception.CustomerNotFound;
import com.capg.cms.service.CustomerServiceImp;



public class Banktest {

	Customer c=new Customer("rahul","jytcfl, sf, jsd, jshfd-500067",8000,"9999999999",23,"ujiky8765y");
	Customer b=new Customer("swetha","dfgf, sf, jsd, jshfd-500067",1000,"8888888888",45,"lokij7654r");
	CustomerServiceImp a=new CustomerServiceImp();
	@Test
	public void testAddCustomer() throws CustomerNotFound {
		c.setAccno(100901010);
		c.setPin(908);
		assertNotEquals("false",a.addCustomer(c));
	}

	@Test
	public void testShowBalance() throws CustomerNotFound {
		assertNotNull(b);
		assertNotNull(c);
	}

	@Test
	public void testDeposit() throws CustomerNotFound {
		assertNotNull(b);
		assertNotNull(c);
	}

	@Test
	public void testWithDraw() throws CustomerNotFound {
		assertNotNull(b);
		assertNotNull(c);
	}

	@Test
	public void testFundTransfer() throws CustomerNotFound {
		int amount=c.getAmt();
		assertNotNull(a.fundTransfer(c, b, amount, c.getAccno(), b.getAccno(), c.getPin()));
	}

	@Test
	public void testPrintTransaction() {
		assertNotNull(c);
	}

}
