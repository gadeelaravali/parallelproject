package com.capg.cms.service;

import java.util.List;

import com.capg.cms.beans.Customer;
import com.capg.cms.beans.Transaction;
import com.capg.cms.exception.CustomerNotFound;


public interface ICustomerService {

	
   public boolean addCustomer(Customer c) throws CustomerNotFound;
  public int displayCustomer(int accno,int pinno) throws CustomerNotFound; 
  public Customer displayCust(int accno);
   public	int withDraw(Customer c1,int wd) throws CustomerNotFound;
   public int depositAmt(int da,Customer c,int accno,int pin) throws CustomerNotFound;
 //  public Customer printTransaction(Customer c) ; 

	public boolean validateAccno(int accno) throws CustomerNotFound;
	public boolean validatePinno(int accno,int pinno) throws CustomerNotFound;
	public boolean fundTransfer(Customer c,Customer b,int amt,int accno1,int accno2,int pinno) throws CustomerNotFound;
	
	public List<Transaction>  printTransactions(int cid,int pinno) throws CustomerNotFound;;
	
	
}
