package com.capg.cms.dao;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import com.capg.cms.beans.Customer;
import com.capg.cms.exception.CustomerNotFound;
import com.capg.cms.beans.Transaction;
public class CustomerDAOImp implements ICustomerDAO {
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("Parallell");
	Transaction transaction=new Transaction();
	DateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
	Date date =new Date();

	@Override
	public boolean addCustomer(Customer cus) throws CustomerNotFound{
		EntityManager em=factory.createEntityManager();
		try{

			em.getTransaction().begin();

			em.persist(cus);
			em.getTransaction().commit();
			return em.contains(cus);
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {    
			em.close();
		}
	}


	@Override
	public boolean validateAccno(int id1) throws CustomerNotFound {
		EntityManager em=factory.createEntityManager();
		boolean flag=false;
		try{
			Customer customer=em.find(Customer.class, id1);
			if(customer==null)
			{
				flag=false;
			}else if(customer.getAccno()==id1){
				flag=true;
			}
			return flag;
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
	}
	@Override
	public boolean validatePinno(int id1,int id2) throws CustomerNotFound {

		boolean flag=false;

		EntityManager em=factory.createEntityManager();
		try{
		
			Customer customer=em.find(Customer.class,id1);
			if(customer.getPin()==id2){
				flag=true;
			}
			return flag;
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}

	}

	public int displayCustomer(int id1,int id2) throws CustomerNotFound {	

		int a=0;
				EntityManager em=factory.createEntityManager();
		try{

			Customer customer=em.find(Customer.class,id1);
			if(customer.getAccno()==id1&&customer.getPin()==id2){
				a=customer.getAmt();
				System.out.println("Balance is:"+a);
			}else{
				System.out.println("Please enter Correct pin");
			}
			return a;
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}

	}
	public int withDraw(Customer c1,int wd) throws CustomerNotFound {

		EntityManager em=factory.createEntityManager();
		if(c1.getAmt()>wd){
			try{
				em.getTransaction().begin();
				int bal=0;
				bal=c1.getAmt()-wd;
			transaction.setTransaction("  "+dateFormat.format(date)+"    withdraw       "+wd+"                             "+bal);				
				c1.setAmt(bal);
				c1.addTransaction(transaction);
				em.merge(c1);
				em.getTransaction().commit();	
				return c1.getAmt();
			}catch(PersistenceException e) {
				e.printStackTrace();
				//TODO: Log to file
				throw new CustomerNotFound(e.getMessage());
			}finally {
				em.close();
			}
		}
		return c1.getAmt();

	}
	public int depositAmt(int da,Customer c,int accno,int pin) throws CustomerNotFound {
	
		EntityManager em=factory.createEntityManager();
		try{
			if(c.getAccno()==accno&&c.getPin()==pin){
				em.getTransaction().begin();
				int bal=0;
				bal=c.getAmt()+da;
				transaction.setTransaction("  "+dateFormat.format(date)+"    deposit     "+da+"                             "+bal);
				c.setAmt(bal);	
				c.addTransaction(transaction);
				em.merge(c);
				em.getTransaction().commit();	
				return c.getAmt();
			}else
			{
				return 0;
			}
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
	}
	@Override
	public List<Transaction> printTransactions(int cid,int pin) throws CustomerNotFound{
		// TODO Auto-generated method stub

		EntityManager em=factory.createEntityManager();
		try{
			Customer c=em.find(Customer.class, cid);
			if(c.getAccno()==cid&&c.getPin()==pin){
				List<Transaction> TransList=c.getTransactions();
				return TransList;
			}
			return null;
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
	}

	public Customer displayCust(int accno) {
		Customer custo=null;
		EntityManager em=factory.createEntityManager();
		try{
			custo=em.find(Customer.class,accno);
			return custo;
		}
		catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			try {
				throw new CustomerNotFound(e.getMessage());
			} catch (CustomerNotFound e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally {
			em.close();
		}
		return custo;

	}
	public boolean fundTransfer(Customer c,Customer b,int amt,int accno1,int accno2,int pinno) throws CustomerNotFound
	{
		boolean flag=false;
		if(c.getAccno()==accno1&&c.getPin()==pinno){
			if(b.getAccno()==accno2){
				if(c.getAmt()>amt){
					EntityManager em=factory.createEntityManager();
					try{
						em.getTransaction().begin();
						int bal=c.getAmt();
						bal=bal-amt;					
						transaction.setTransaction("  "+dateFormat.format(date)+"   fundTranfer     "+amt+"                             "+bal);			
						c.setAmt(bal);
						c.addTransaction(transaction);
						em.merge(c);
						int bal1=b.getAmt();
						bal1=bal1+amt;
						transaction.setTransaction("  "+dateFormat.format(date)+"   fundTranfer     "+amt+"                             "+bal1);
				
						b.setAmt(bal1);
						b.addTransaction(transaction);
						em.merge(b);
						em.getTransaction().commit();	
						flag=true;
					}catch(PersistenceException e) {
						e.printStackTrace();
						//TODO: Log to file
						throw new CustomerNotFound(e.getMessage());
					}finally {
						em.close();
					}
				}
			}
		}
		return flag;
	}



}

