package com.capg.cms.ui;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capg.cms.beans.Customer;
import com.capg.cms.beans.Transaction;
import com.capg.cms.exception.CustomerNotFound;
import com.capg.cms.service.CustomerServiceImp;

public class Client {
	public static void main(String[] args) throws CustomerNotFound,NullPointerException {

		// TODO Auto-generated method stub
		CustomerServiceImp service = new CustomerServiceImp();

		while (true) {
			System.out.println("WELCOME TO CUSTOMER MANAGMENT");
			System.out.println("-------------------------------------");
			System.out.println("1.ADD CUSTOMER");
			System.out.println("2.SHOW BALANCE");
			System.out.println("3.DEPOSIT AMOUNT");
			System.out.println("4.WITHDRAW AMOUNT");
			System.out.println("5.FUND TRANSFER");
			System.out.println("6.PRINT TRANSACTIONS");
			System.out.println("7.EXIT");
			System.out.println("-------------------------------------");
			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();
			switch (choice) {
			case 1:		
				Customer bean = new Customer(null,null,0,null,0,null);
				boolean validname=false;
				boolean validphno = false;
				boolean validage = false;	
				boolean validpan = false;
				do{					
					System.out.println("ENTER CUSTOMER FIRST NAME");
					String cname = sc.next();
					if(service.validateName(cname))
					{bean.setCname(cname);
					validname=true;
					do				
					{
						System.out.println("ENTER CUSTOMER MOBILENO");
						String mobileno = sc.next();
						if(service.validatePhno(mobileno))					
						{	bean.setMobileno(mobileno);
						validphno=true;

						do
						{
							System.out.println("ENTER CUSTOMER PANNO");
							String panno = sc.next().toUpperCase();
							if(service.validatePan(panno))
							{bean.setPanno(panno);
							validpan=true;
							do
							{
								System.out.println("ENTER CUSTOMER AGE");
								int age = sc.nextInt();
								if(service.validateAge(age))
								{bean.setAge(age);
								validage=true;
								System.out.println("ENTER CUSTOMER ADDR");
								String addr = new String();
								System.out.println("ENTER HOUSE NO");
								String addr1 =sc.next();

								System.out.println("ENTER STREET NAME");
								String addr2 = sc.next();

								System.out.println("ENTER CITY NAME");
								String addr3 = sc.next();

								System.out.println("ENTER STATE NAME");
								String addr4 =sc.next();

								System.out.println("ENTER PINCODE");
								String addr5 = sc.next();

								addr=addr1+","+addr2+","+addr3+","+addr4+","+addr5;
								bean.setAddr(addr);
								System.out.println("ENTER BALANCE"); 
								Integer amt = sc.nextInt();
								//String s=amt.toString();					
								if(((amt>=0)))
								{				 bean.setAmt(amt);	 
								boolean isAdded;
								try {
									isAdded = service.addCustomer(bean);
									if (validname && validphno && isAdded && validage && validpan) 
									{
										System.out.println("added successfully");
										System.out.println(bean);
									} else
										System.out.println("not added");

								} catch (CustomerNotFound e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
									System.out.println(e.getMessage());
								}

								}else
								{	
									try {
										throw new CustomerNotFound("PLEASE ENTER MINIMUM BALANCE");
									} catch (CustomerNotFound e) {
										// TODO: handle exception
										System.out.println(e.getMessage());

									}			
								}
								}else
									System.out.println("PLEASE ENTER CORRECT AGE");
							}while(!validage);
							}else
								System.out.println("PLEASE ENTER CORRECT PAN NO");
						}while(!validpan);
						}else
							System.out.println("PLEASE ENTER CORRECT MOBILE NO");
					}while(!validphno);
					}
					else
						System.out.println("PLEASE ENTER CORRECT NAME");
				}while(!validname);
				break;
			case 2:
				boolean validacc=false;
				boolean validpin=false;
				do{
					System.out.println("ENTER ACCNO TO GET BALANCE");
					int id1 = sc.nextInt();

					if(service.validateAccno(id1))
					{
						validacc=true;

						do{
							System.out.println("ENTER PIN");
							int id2=sc.nextInt();
							boolean validpinno = service.validatePinno(id1,id2);
							if(validpinno)
							{	validpin=true;								
							try {
								int c = service.displayCustomer(id1,id2);
							} catch (CustomerNotFound e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}			

							}
							else
							{
								System.out.println("ENTER VALID PIN FOR YOUR ACCOUNT");
							}
						}	while(!validpin);
					}
					else {	
						try {
							throw new CustomerNotFound("ENTER VALID ACCOUNT");
						} catch (CustomerNotFound e) {
							// TODO: handle exception
							System.out.println(e.getMessage());
						}
						catch(NullPointerException e)
						{
							System.out.println("ENTER VALID ACCOUNT NUMBER"+e.getMessage());
						}
					}
				}while(!validacc);
				break;							


			case 3: 
				System.out.println("ENTER ACCNO TO DEPOSIT");
				int id3 = sc.nextInt();				

				if (service.validateAccno(id3))
				{
					System.out.println("ENTER PIN");
					int id4=sc.nextInt();
					boolean validpinno1 = service.validatePinno(id3,id4);
					if(validpinno1)
					{	System.out.println("----------DEPOSIT--------------");
						System.out.println("ENTER AMOUNT TO DEPOSIT");
						int da = sc.nextInt();
						Customer c=service.displayCust(id3);	
						int b=c.getAmt();
						int a= service.depositAmt(da,c,id3,id4);	
						if(a>b){
							System.out.println("DEPOSITED DONE SUCCESSFULLY");
							System.out.println("UPDATED BALANCE: "+a);
							break;
						}else {
							System.out.println("DEPOSIT FAILED");
						}
					}
					else
						System.out.println("PLEASE ENTER CORRECT PIN");
				}
				else
				{
					try {
						throw new CustomerNotFound("ENTER VALID ACCOUNT");
					} catch (CustomerNotFound e) {
						// TODO: handle exception
						System.out.println(e.getMessage());	
					}
				}
				break;
			case 4:
				System.out.println("ENTER ACCNO TO WITHDRAW");
				int id5 = sc.nextInt();							
				boolean validaccno2 = service.validateAccno(id5);
				if (validaccno2) {	
					System.out.println("ENTER PIN");
					int id6=sc.nextInt();
					boolean validpinno2 = service.validatePinno(id5,id6);
					if(validpinno2)
					{	Customer c=service.displayCust(id5);
					if(c.getAccno()==id5 && c.getPin()==id6)
					{System.out.println("------------WITHDRAW--------------");

						System.out.println("ENTER AMOUNT TO WITHDRAW");
						int wd = sc.nextInt();
						int at=c.getAmt();
						int a = service.withDraw(c,wd);				
						if(a<at)
						{
							System.out.println("WITHDRAW DONE SUCCESSFULLY");
							System.out.println("BALANCE:"+a);
						}
						else
							System.out.println("WITHDRAW FAILED");
					}else
						System.out.println("ENTER VALID PIN FOR YOUR ACCOUNT");
					}else
						System.out.println("VALID PIN");
				}
				else
				{
					try {
						throw new CustomerNotFound("ENTER VALID ACCOUNT");
					} catch (CustomerNotFound e) {
						// TODO: handle exception
						System.out.println(e.getMessage());
					}		}

				break; 
			case 5:System.out.println("ENTER YOUR ACCOUNT NUMBER");			  
			int id7 = sc.nextInt();		
			boolean validaccno3 = service.validateAccno(id7);
			Customer c = service.displayCust(id7);
			if(validaccno3)
			{		
				System.out.println("ENTER PIN");
				int id8=sc.nextInt();
				boolean validpinno = service.validatePinno(id7,id8);
				if((c.getAccno()==id7)&&(c.getPin()==id8)){				
					System.out.println("ENTER  ACCOUNT NUMBER TO TRANSFER");				  
					int id9 = sc.nextInt();	
					if(validpinno)
					{
						boolean validaccno4 = service.validateAccno(id9);
						if (validaccno4) {			
							System.out.println("ENTER AMOUNT TO TRANSFER");
							int at = sc.nextInt();	
							Customer b=service.displayCust(id9);

							boolean z=service.fundTransfer(c, b, at, id7, id9, id8);			
							if(z){						 

								System.out.println("TRANSACTION DONE SUCCESSFUL");
								System.out.println("BALANCE IN YOUR ACCOUNT"+c.getAmt());
								System.out.println("BALANCE IN OTHER ACCOUNT"+b.getAmt());										
							}else{
								System.out.println("TRANSACTION FAILED");}


						}else{
							try {
								throw new CustomerNotFound("ENTER VALID ACCOUNT OF OTHERS TO TRANSFER");
							} catch (CustomerNotFound e) {
								// TODO: handle exception
								System.out.println(e.getMessage());
							}
						}
					}	
				}else{
					try {
						throw new CustomerNotFound("ENTER VALID PIN FOR YOUR ACCOUNT");
					} catch (CustomerNotFound e) {
						// TODO: handle exception
						System.out.println(e.getMessage());
					}
				}
			}else{
				try {
					throw new CustomerNotFound("YOUR ACCOUNT NUMBER IS NOT CORRECT");
				} catch (CustomerNotFound e) {
					// TODO: handle exception
					System.out.println(e.getMessage());
				}	
			}
			break;
			case 6:
				System.out.println("---------PRINT TRANSACTIONS-----------");
				System.out.println("ENTER YOUR ACCOUNT NUMBER");			  
				int id12 = sc.nextInt();			
				if(id12!=0)
				{
					boolean validaccno5 = service.validateAccno(id12);				
					System.out.println("ENTER PIN");
					int id13=sc.nextInt();
					boolean validpinno5 = service.validatePinno(id12,id13);
					Customer c1 = service.displayCust(id12);
					if((c1.getAccno()==id12)&&(c1.getPin()==id13))
					{									
						List<Transaction> list=service.printTransactions(id12, id13);
						if(list==null){
							System.out.println("PLEASE ENTER CORRECT ACCOUNT NUMBER AND PIN");
						}else{
							Transaction a=new Transaction();					
							Iterator<Transaction> iterator = list.iterator();
							System.out.println(iterator.next());
							while(iterator.hasNext()){
								System.out.println(iterator.next());
							}
							System.out.println("-----------------------------------------------");
							System.out.println("                         CURRENT BALANCE      "+c1.getAmt());
						}

					}else {
						System.err.println("PLEASE ENTER VALID PIN");
					}
				}
				else {
					try {
						throw new CustomerNotFound("PLEASE ENTER VALID ACCOUNT NUMBER");
					} catch (CustomerNotFound e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
				}
				break; 
			case 7: System.exit(0);
			        break;	
			default:
				break;
			}

		}

	}
}
