package com.capg.cms.exception;
public class CustomerNotFound extends Exception{


public CustomerNotFound (String getMessage)
{
	super(getMessage);
}
	

}
