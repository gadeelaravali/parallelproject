package com.capg.cms.service;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.cms.beans.Customer;
import com.capg.cms.beans.Transaction;
import com.capg.cms.dao.CustomerDAOImp;
import com.capg.cms.exception.CustomerNotFound;
public class CustomerServiceImp implements ICustomerService {
	CustomerDAOImp dao = new CustomerDAOImp();
	@Override
	public boolean addCustomer(Customer c) throws CustomerNotFound {
		// TODO Auto-generated method stub
		return dao.addCustomer(c);
	}
@Override
	public int displayCustomer(int accno,int pinno) throws CustomerNotFound {
		// TODO Auto-generated method stub
	return dao.displayCustomer(accno,pinno);
	}

	public int withDraw(Customer c1,int wd) throws CustomerNotFound
	{
		return dao.withDraw(c1,wd);
		
	}
	public int depositAmt(int da,Customer c,int accno,int pin) throws CustomerNotFound
	{
		return dao.depositAmt(da,c,accno,pin);
		
	}
	
/*	public Customer printTransaction(Customer cid) {
		// TODO Auto-generated method stub
		return dao.printTransaction(cid);*/
	//}
	public List<Transaction> printTransactions(int cid, int pinno)throws CustomerNotFound {
		// TODO Auto-generated method stub
		return dao.printTransactions(cid, pinno);
	}
	/*public void displayBalance() {
		// TODO Auto-generated method stub
		
	}*/
	public boolean validateAccno(int accno) throws CustomerNotFound {
		// TODO Auto-generated method stub
		
		return dao.validateAccno(accno);
	}
	public boolean validatePinno(int accno,int pinno) throws CustomerNotFound {
		// TODO Auto-generated method stub
		
		return dao.validatePinno(accno,pinno);
	}
	public Customer displayCust(int accno) {
		return dao.displayCust(accno);
	}
	public boolean fundTransfer(Customer c,Customer b,int amt,int accno1,int accno2,int pinno) throws CustomerNotFound
	{
		return dao.fundTransfer(c,b,amt,accno1,accno2,pinno);
	}

public boolean validatePhno(String mobileno)
{
	boolean flag = false;
    Pattern pattern = Pattern.compile("^(0/91)?[7-9][0-9]{9}");
    Matcher matcher = pattern.matcher(mobileno);
    if(matcher.matches())
    {
        flag=true;
    }
	return flag;	
}
public boolean validateName(String name)
{
	boolean flag = false;
	if(name.matches("^[A-Za-z\\s]+$"))
	{
		flag = true;
	}
	return flag;	
}
public boolean validateAge(int age)
{
	boolean flag = false;
	if(age>18 && age<100)
	{
		flag = true;
	}
	return flag;	
}
public boolean validatePan(String panno)
{
	boolean flag = false;
	if(panno.matches("^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}"))
	{
		flag = true;
	}
	return flag;	
}

}



 
