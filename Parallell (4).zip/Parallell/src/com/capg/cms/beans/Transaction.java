package com.capg.cms.beans;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Transactions")

public class Transaction implements Serializable{
private static final long serialVersionUID=1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
private int tranid;	
private String transaction;
@ManyToOne
@JoinColumn(name="accountNum")
private Customer customer;
public int getTranid() {
	return tranid;
}
public void setTranid(int tranid) {
	this.tranid = tranid;
}
public String getTransaction() {
	return transaction;
}
public void setTransaction(String transaction) {
this.transaction = transaction;
}
public Customer getCustomer() {
	return customer;
}
public void setCustomer(Customer customer) {
	this.customer = customer;
}
public Transaction(int tranid, String transaction, Customer customer) {
	super();
	this.tranid = tranid;
	this.transaction = transaction;
	this.customer = customer;
}
public Transaction() {
	super();
	
}
@Override
public String toString() {
	return "Transaction [transaction=" + transaction+"]";
}

	
}



